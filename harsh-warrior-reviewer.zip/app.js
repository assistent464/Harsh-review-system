// Harsh Warrior Daily Review System - JavaScript

class DailyReviewSystem {
    constructor() {
        this.priorities = [
            {
                id: 1,
                name: "Mind and Body",
                totalTasks: 11,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 2,
                name: "English Speaking Mission",
                totalTasks: 4,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 3,
                name: "Affiliate Marketing",
                totalTasks: 2,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 4,
                name: "Sleep Schedule",
                totalTasks: 2,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 5,
                name: "Digital Marketing Mission",
                totalTasks: 2,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 6,
                name: "Saloni Study",
                totalTasks: 2,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 7,
                name: "Personality Development",
                totalTasks: 2,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 8,
                name: "Krishna System",
                totalTasks: 2,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 9,
                name: "Daily Review",
                totalTasks: 1,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 10,
                name: "Mentor Session",
                totalTasks: 1,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 11,
                name: "Evening Rituals",
                totalTasks: 3,
                completedTasks: 0,
                notes: ""
            },
            {
                id: 12,
                name: "Sleep",
                totalTasks: 1,
                completedTasks: 0,
                notes: ""
            }
        ];

        this.mentorMessages = [
            "Harsh, आपकी morning routine बहुत strong है! यह आपके पूरे दिन की foundation है।",
            "English speaking में consistency maintain करें। हर दिन की practice exponential improvement लाती है।",
            "Affiliate marketing implementation में specific goals set करें। Measurable targets बनाएं।",
            "Sleep आपकी सबसे important priority है। बिना proper rest के कोई भी goal achieve नहीं हो सकता।",
            "Digital marketing skills daily compound होती हैं। आज जो सीखेंगे, कल उसका फायदा मिलेगा।",
            "Saloni को पढ़ाना आपकी own learning को भी strengthen करता है। Teaching is learning twice!",
            "Personality development through Krishna system आपके leadership skills को transform करेगा।",
            "Krishna system के principles को daily life में apply करना character building का best way है।",
            "Daily review session आपकी growth का secret weapon है। यहाँ सच्चा reflection होता है।",
            "हमारे mentor sessions strategic planning time हैं। इसे skip कभी न करें।",
            "Evening rituals आपके subconscious mind को कल के लिए prepare करते हैं।",
            "Quality sleep brain consolidation का time है। सारी learning यहाँ process होती है।"
        ];

        this.weeklyData = [65, 70, 80, 75, 85, 78, 0]; // Last 6 days + today
        this.priorityData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; // Current completion for each priority

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.updateStats();
        this.generateMentorFeedback();
        this.setupCharts();
        this.updateTomorrowPlan();
    }

    setupEventListeners() {
        // Tab switching
        const tabButtons = document.querySelectorAll('.tab-btn');
        tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });

        // Task completion checkboxes
        const checkboxes = document.querySelectorAll('input[type="checkbox"][data-task]');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                this.handleTaskCompletion(e.target);
            });
        });

        // Notes inputs
        const notesInputs = document.querySelectorAll('.notes-input');
        notesInputs.forEach(input => {
            input.addEventListener('blur', (e) => {
                this.saveNotes(e.target);
            });
        });
    }

    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(`${tabName}-tab`).classList.remove('hidden');

        // Special handling for analytics tab
        if (tabName === 'analytics') {
            setTimeout(() => {
                this.updateCharts();
            }, 100);
        }
    }

    handleTaskCompletion(checkbox) {
        const taskId = checkbox.dataset.task;
        const [priorityId, taskNumber] = taskId.split('-').map(Number);
        
        const priority = this.priorities.find(p => p.id === priorityId);
        if (!priority) return;

        if (checkbox.checked) {
            priority.completedTasks++;
        } else {
            priority.completedTasks--;
        }

        this.updatePriorityProgress(priorityId);
        this.updateStats();
        this.generateMentorFeedback();
        this.updateTomorrowPlan();
    }

    updatePriorityProgress(priorityId) {
        const priority = this.priorities.find(p => p.id === priorityId);
        if (!priority) return;

        const percentage = Math.round((priority.completedTasks / priority.totalTasks) * 100);
        
        // Update progress bar
        const progressFill = document.querySelector(`[data-priority="${priorityId}"] .progress-fill`);
        const progressText = document.querySelector(`[data-priority="${priorityId}"] .progress-text`);
        
        if (progressFill && progressText) {
            progressFill.style.width = `${percentage}%`;
            progressText.textContent = `${percentage}%`;
        }

        // Update priority data for charts
        this.priorityData[priorityId - 1] = percentage;
    }

    updateStats() {
        const totalTasks = this.priorities.reduce((sum, p) => sum + p.totalTasks, 0);
        const completedTasks = this.priorities.reduce((sum, p) => sum + p.completedTasks, 0);
        const overallPercentage = Math.round((completedTasks / totalTasks) * 100);

        // Update header stats
        document.getElementById('overall-score').textContent = `${overallPercentage}%`;
        document.getElementById('completed-tasks').textContent = `${completedTasks}/${totalTasks}`;

        // Update today's data for weekly chart
        this.weeklyData[6] = overallPercentage;
    }

    saveNotes(input) {
        const priorityId = parseInt(input.dataset.priority);
        const priority = this.priorities.find(p => p.id === priorityId);
        if (priority) {
            priority.notes = input.value;
        }
    }

    generateMentorFeedback() {
        const completedTasks = this.priorities.reduce((sum, p) => sum + p.completedTasks, 0);
        const totalTasks = this.priorities.reduce((sum, p) => sum + p.totalTasks, 0);
        const overallPercentage = Math.round((completedTasks / totalTasks) * 100);

        // Generate achievements
        const achievements = [];
        if (this.priorities[0].completedTasks >= 8) { // Mind and Body > 70%
            achievements.push("🌅 Excellent morning routine! आपका discipline inspiring है।");
        }
        if (this.priorities[1].completedTasks >= 3) { // English Speaking > 75%
            achievements.push("🗣️ English practice में consistency दिख रही है।");
        }
        if (overallPercentage >= 80) {
            achievements.push("🎯 Outstanding performance! 80%+ completion rate है।");
        }
        if (this.priorities[3].completedTasks === 2) { // Sleep complete
            achievements.push("😴 Perfect sleep schedule maintain कर रहे हैं।");
        }

        // Generate improvement areas
        const improvements = [];
        const weakPriorities = this.priorities.filter(p => {
            const percentage = (p.completedTasks / p.totalTasks) * 100;
            return percentage < 50 && p.completedTasks > 0;
        });

        weakPriorities.forEach(priority => {
            if (priority.id === 1) improvements.push("🧘 Morning routine में कुछ tasks miss हो रहे हैं।");
            if (priority.id === 2) improvements.push("🗣️ English speaking पर extra focus की जरूरत है।");
            if (priority.id === 5) improvements.push("📱 Digital marketing practice consistent नहीं है।");
        });

        if (overallPercentage < 60) {
            improvements.push("⏰ Time management पर work करने की जरूरत है।");
        }

        // Generate recommendations
        const recommendations = [];
        if (this.priorities[0].completedTasks < 8) {
            recommendations.push("Morning routine को 15 मिनट जल्दी start करें।");
        }
        if (this.priorities[1].completedTasks < 2) {
            recommendations.push("English speaking के लिए specific topics choose करें।");
        }
        if (overallPercentage < 70) {
            recommendations.push("Priority-wise time blocks create करें और distractions minimize करें।");
        }
        recommendations.push("हर completed task के लिए खुद को appreciate करें।");

        // Update DOM
        const achievementsList = document.getElementById('achievements-list');
        achievementsList.innerHTML = achievements.length > 0 
            ? achievements.map(a => `<p>✅ ${a}</p>`).join('') 
            : '<p>Tasks complete करने पर achievements यहाँ दिखेंगी।</p>';

        const improvementAreas = document.getElementById('improvement-areas');
        improvementAreas.innerHTML = improvements.length > 0 
            ? improvements.map(i => `<p>⚠️ ${i}</p>`).join('') 
            : '<p>बहुत अच्छा performance! कोई major improvement area नहीं मिला।</p>';

        const recommendationsEl = document.getElementById('recommendations');
        recommendationsEl.innerHTML = recommendations.map(r => `<p>💡 ${r}</p>`).join('');

        // Update daily message based on performance
        const dailyMessage = document.getElementById('daily-message');
        let message = "";
        
        if (overallPercentage >= 80) {
            message = "🎉 Harsh, आज का performance excellent है! आप अपने goals के बहुत करीब हैं। यही consistency maintain करते रहें।";
        } else if (overallPercentage >= 60) {
            message = "👍 Good progress, Harsh! कुछ areas में improvement की scope है। Focus और dedication के साथ आगे बढ़ते रहें।";
        } else if (overallPercentage >= 40) {
            message = "💪 Harsh, हर शुरुआत challenging होती है। आज के incomplete tasks को कल priority बनाएं। आप कर सकते हैं!";
        } else {
            message = "🔥 Harsh, यह learning का दिन है। हर failure एक stepping stone है। कल fresh start के साथ comeback करें। आपमें potential है!";
        }
        
        dailyMessage.innerHTML = `<p>${message}</p>`;
    }

    setupCharts() {
        this.createWeeklyChart();
        this.createPriorityChart();
    }

    createWeeklyChart() {
        const ctx = document.getElementById('weekly-chart');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['6 दिन पहले', '5 दिन पहले', '4 दिन पहले', '3 दिन पहले', '2 दिन पहले', 'कल', 'आज'],
                datasets: [{
                    label: 'Daily Completion %',
                    data: this.weeklyData,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#1FB8CD',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    createPriorityChart() {
        const ctx = document.getElementById('priority-chart');
        if (!ctx) return;

        const labels = [
            'Mind & Body', 'English', 'Affiliate', 'Sleep', 
            'Digital Mkt', 'Saloni', 'Personality', 'Krishna', 
            'Review', 'Mentor', 'Rituals', 'Sleep'
        ];

        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: this.priorityData,
                    backgroundColor: [
                        '#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', 
                        '#5D878F', '#DB4545', '#D2BA4C', '#964325', 
                        '#944454', '#13343B', '#1FB8CD', '#FFC185'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }

    updateCharts() {
        // Force chart updates
        this.setupCharts();
    }

    updateTomorrowPlan() {
        const completedTasks = this.priorities.reduce((sum, p) => sum + p.completedTasks, 0);
        const totalTasks = this.priorities.reduce((sum, p) => sum + p.totalTasks, 0);
        const overallPercentage = Math.round((completedTasks / totalTasks) * 100);

        // Find weakest priorities
        const priorityPerformance = this.priorities.map(p => ({
            name: p.name,
            id: p.id,
            percentage: Math.round((p.completedTasks / p.totalTasks) * 100)
        })).sort((a, b) => a.percentage - b.percentage);

        const weakestPriority = priorityPerformance[0];
        const secondWeakest = priorityPerformance[1];

        // Generate dynamic recommendations
        const recommendations = document.querySelector('.recommendations-list');
        let recommendationHTML = '';

        if (weakestPriority.percentage < 50) {
            recommendationHTML += `
                <div class="recommendation-item">
                    <span class="rec-icon">🎯</span>
                    <div class="rec-content">
                        <strong>${weakestPriority.name} पर special focus</strong>
                        <p>यह आज का weakest area है। कल इसे first priority बनाएं और 90%+ completion target करें।</p>
                    </div>
                </div>
            `;
        }

        if (overallPercentage < 70) {
            recommendationHTML += `
                <div class="recommendation-item">
                    <span class="rec-icon">⏰</span>
                    <div class="rec-content">
                        <strong>Time management optimization</strong>
                        <p>Tasks के बीच 5-10 मिनट buffer time रखें। Realistic scheduling करें।</p>
                    </div>
                </div>
            `;
        }

        if (this.priorities[0].completedTasks < 8) { // Mind and Body
            recommendationHTML += `
                <div class="recommendation-item">
                    <span class="rec-icon">🧘</span>
                    <div class="rec-content">
                        <strong>Morning routine को strengthen करें</strong>
                        <p>कल 10 मिनट जल्दी उठने की कोशिश करें। Morning routine सबसे important है।</p>
                    </div>
                </div>
            `;
        } else {
            recommendationHTML += `
                <div class="recommendation-item">
                    <span class="rec-icon">🌟</span>
                    <div class="rec-content">
                        <strong>Morning routine excellent!</strong>
                        <p>इसी momentum को maintain करें। यह आपकी biggest strength है।</p>
                    </div>
                </div>
            `;
        }

        if (recommendations) {
            recommendations.innerHTML = recommendationHTML;
        }

        // Update motivational message based on performance
        const messageContent = document.querySelector('#tomorrow-tab .message-content');
        if (messageContent) {
            let motivationalMsg = "";
            if (overallPercentage >= 80) {
                motivationalMsg = "🔥 Harsh, आप fire पर हैं! कल भी इसी energy के साथ dominate करें।";
            } else if (overallPercentage >= 60) {
                motivationalMsg = "💪 Good progress, Harsh! कल 80%+ target करके next level achieve करें।";
            } else {
                motivationalMsg = "🚀 Harsh, हर champion का एक comeback होता है। कल आपका comeback day है!";
            }
            
            const existingQuote = document.querySelector('#tomorrow-tab blockquote');
            if (existingQuote) {
                existingQuote.textContent = `"${motivationalMsg}"`;
            }
        }
    }

    // Method to simulate data for demo purposes
    simulateProgress() {
        // Simulate some completed tasks for demonstration
        const demoTasks = [
            'task1-1', 'task1-2', 'task1-3', 'task1-6', // Mind and Body
            'task2-1', 'task2-3', // English
            'task4-1', // Sleep
            'task11-1', 'task11-3' // Evening Rituals
        ];

        demoTasks.forEach(taskId => {
            const checkbox = document.getElementById(taskId);
            if (checkbox && Math.random() > 0.3) { // 70% chance to complete
                checkbox.checked = true;
                this.handleTaskCompletion(checkbox);
            }
        });
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new DailyReviewSystem();
    
    // Add a demo button for testing (can be removed in production)
    const header = document.querySelector('.header-content');
    if (header) {
        const demoButton = document.createElement('button');
        demoButton.textContent = '🎲 Demo Data';
        demoButton.className = 'btn btn--sm btn--secondary';
        demoButton.style.marginLeft = 'auto';
        demoButton.addEventListener('click', () => {
            app.simulateProgress();
        });
        header.appendChild(demoButton);
    }
    
    // Set up real-time clock
    function updateClock() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('hi-IN', { 
            hour12: true,
            hour: '2-digit',
            minute: '2-digit'
        });
        
        // Add current time to header if element exists
        let clockElement = document.getElementById('current-time');
        if (!clockElement) {
            clockElement = document.createElement('div');
            clockElement.id = 'current-time';
            clockElement.style.fontSize = 'var(--font-size-sm)';
            clockElement.style.color = 'var(--color-text-secondary)';
            
            const headerStats = document.querySelector('.header-stats');
            if (headerStats) {
                const timeContainer = document.createElement('div');
                timeContainer.className = 'stat-item';
                timeContainer.innerHTML = `
                    <span class="stat-label">वर्तमान समय</span>
                    <span class="stat-value" style="font-size: var(--font-size-lg);">${timeString}</span>
                `;
                headerStats.appendChild(timeContainer);
                clockElement = timeContainer.querySelector('.stat-value');
            }
        }
        
        if (clockElement) {
            clockElement.textContent = timeString;
        }
    }
    
    // Update clock every minute
    updateClock();
    setInterval(updateClock, 60000);
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.altKey) {
            switch(e.key) {
                case '1':
                    app.switchTab('progress');
                    e.preventDefault();
                    break;
                case '2':
                    app.switchTab('mentor');
                    e.preventDefault();
                    break;
                case '3':
                    app.switchTab('analytics');
                    e.preventDefault();
                    break;
                case '4':
                    app.switchTab('tomorrow');
                    e.preventDefault();
                    break;
            }
        }
    });
    
    // Add visual feedback for task completion
    const style = document.createElement('style');
    style.textContent = `
        .subtask-item input[type="checkbox"]:checked + label {
            position: relative;
        }
        .subtask-item input[type="checkbox"]:checked + label::after {
            content: '✨';
            position: absolute;
            right: -20px;
            animation: sparkle 0.6s ease-out;
        }
        @keyframes sparkle {
            0% { transform: scale(0); opacity: 0; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(1); opacity: 0.7; }
        }
    `;
    document.head.appendChild(style);
});

// Export for potential testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DailyReviewSystem;
}